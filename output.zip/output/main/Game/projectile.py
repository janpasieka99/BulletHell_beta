import pygame
import math


def collision_detection(character1, character2):
    distance = math.sqrt(((character1.x - character2.x) ** 2) + ((character1.y - character2.y) ** 2))
    if distance <= character1.radius + character2.radius:
        return True
    else:
        return False


class Projectile(object):
    def __init__(self, x, y, radius, facing, projectile_range, color, damage, velocity, source):
        self.x = x
        self.y = y
        self.radius = radius
        self.facing = facing
        self.projectile_range = projectile_range
        self.color = color
        self.damage = damage
        self.source = source
        if facing == 'up':
            self.x_velocity = 0
            self.y_velocity = -1 * velocity
        elif facing == 'down':
            self.x_velocity = 0
            self.y_velocity = velocity
        elif facing == 'left':
            self.x_velocity = -1 * velocity
            self.y_velocity = 0
        elif facing == 'right':
            self.x_velocity = velocity
            self.y_velocity = 0
        else:
            self.x_velocity = round(velocity*facing[0])
            self.y_velocity = round(velocity*facing[1])

    def collision_detection(self, character):
        return collision_detection(self, character)

    def on_map(self, x1, x2, y1, y2):
        if x1 < self.x - self.radius and self.x + self.radius < x2 and y1 < self.y - self.radius and self.y + self.radius < y2:
            return True
        return False

    def move(self, x1, y1, x2, y2):
        if self.projectile_range == 0 or not self.on_map(x1, y1, x2, y2):
            return False
        self.x += self.x_velocity
        self.y += self.y_velocity
        self.projectile_range -= 1
        return True

    def draw(self, win):
        pygame.draw.circle(win, self.color, (round(self.x), round(self.y)), self.radius)

