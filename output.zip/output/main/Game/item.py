import pygame
from abc import ABC


class Item(ABC):
    def __init__(self, type, x, y, texture):
        self.x = x
        self.y = y
        self.radius = 24
        self.type = type
        self.texture = pygame.transform.scale(texture, (48, 48))

    def draw(self, win):
        win.blit(self.texture, (self.x - self.radius, self.y - self.radius))

    def __del__(self):
        self.x = -100
        self.y = -100
        self.type = 'none'
