import pygame


class Textures(object):
    def __init__(self):
        self.bg1 = pygame.image.load('Game/textures/bg1.png')
        self.bg = pygame.image.load('Game/textures/bg.png')
        self.boss_enemy = pygame.image.load('Game/textures/boss_enemy.png')
        self.heal = pygame.image.load('Game/textures/heal.png')
        self.knife = pygame.image.load('Game/textures/knife.png')
        self.melee_enemy = pygame.image.load('Game/textures/melee_enemy.png')
        self.p1 = pygame.image.load('Game/textures/p1.png')
        self.pistol = pygame.image.load('Game/textures/pistol.png')
        self.pistol_ammo = pygame.image.load('Game/textures/pistol_ammo.png')
        self.pistol_enemy = pygame.image.load('Game/textures/pistol_enemy.png')
        self.rifle = pygame.image.load('Game/textures/rifle.png')
        self.rifle_ammo = pygame.image.load('Game/textures/rifle_ammo.png')
        self.rifle_enemy = pygame.image.load('Game/textures/rifle_enemy.png')
        self.shotgun = pygame.image.load('Game/textures/shotgun.png')
        self.shotgun_ammo = pygame.image.load('Game/textures/shotgun_ammo.png')
        self.shotgun_enemy = pygame.image.load('Game/textures/shotgun_enemy.png')
        self.sniper = pygame.image.load('Game/textures/sniper.png')
        self.sniper_ammo = pygame.image.load('Game/textures/sniper_ammo.png')
        self.sniper_enemy = pygame.image.load('Game/textures/sniper_enemy.png')


textures = Textures()
