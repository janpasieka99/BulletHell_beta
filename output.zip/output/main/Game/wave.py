from Game.enemy import MeleeEnemy, PistolEnemy, ShotgunEnemy, RifleEnemy, SniperEnemy, multi_collision
from Game.character import Character
from Game.weapon import Weapon
import pygame
import random


enemies_value = {1: MeleeEnemy, 5: PistolEnemy, 15: ShotgunEnemy, 40: RifleEnemy, 100: SniperEnemy}


class SpawnPoint(Character):
    def __init__(self, x, y):
        super().__init__(x, y, 32, 0, 0, Weapon('null', 0, 0, 0, 0, 0, 0, 0))

    def is_empty(self, enemies, player):
        return not multi_collision(self, player, enemies)

    def pull_enemy(self, enemies, player, wave):
        if len(wave) == 0 or len(enemies) >= 5 or not self.is_empty(enemies, player):
            return 0
        return wave[0]((self.x, self.y)), wave[1:len(wave)]

    def draw(self, win):
        pygame.draw.circle(win, (255, 255, 255), (self.x, self.y), self.radius, 1)


class Wave(object):
    def __init__(self, wave_value, num):
        self.wave_value = wave_value
        self.wave = []
        self.num = num
        self.pause = 600
        self.pause_tick = 0
        self.end = False
        self.just_end = False

    def __next__(self):
        return Wave(round((self.wave_value + 2) * 1.2), self.num + 1)

    def ended(self, enemies):
        if self.end:
            return True
        elif not len(self.wave) and not len(enemies):
            self.pause_tick = 1
            self.end = True
            self.just_end = True
            return True
        return False

    def just_ended(self):
        if self.just_end:
            self.just_end = False
            return True
        return False

    def available(self):
        if self.pause_tick == self.pause:
            self.pause_tick = 0
            self.end = False
            return True
        elif not self.end:
            return False
        elif self.pause_tick:
            self.pause_tick += 1
            return False

    def generate(self):
        num_tab = [1, 5, 15, 40, 100]
        temp_sum = self.wave_value
        while temp_sum > 0:
            random_num = random.Random().choice(num_tab)
            if random_num <= temp_sum:
                self.wave.append(enemies_value[random_num])
                temp_sum -= random_num
