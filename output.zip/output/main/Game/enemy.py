from Game.character import Character
from Game.weapon import *
from abc import abstractmethod
from Game.projectile import collision_detection
from Game.ammo import Ammo
from Game.textures import *
import random
from Game.player import Player


def ok_shoot(shooter,  target):
    if isinstance(shooter, Enemy) and isinstance(target, Player):
        if shooter.facing == 'up' or shooter.facing == 'down':
            if abs(target.x - shooter.x) <= shooter.weapons[0].bullet_range * 0.8:
                return True
        elif shooter.facing == 'right' or shooter.facing == 'left':
            if abs(target.y - shooter.y) <= shooter.weapons[0].bullet_range * 0.8:
                return True
    return False


def multi_collision(it, player, enemies):
    enemies_collision = True
    if not collision_detection(it, player):
        enemies_collision = False
        for enemy in enemies:
            if collision_detection(it, enemy):
                if it == enemy:
                    pass
                else:
                    enemies_collision = True
    return enemies_collision


class Enemy(Character):
    def __init__(self, x, y, radius, hp, velocity, weapons, texture):
        super().__init__(x, y, radius, hp, velocity, weapons)
        self.texture = pygame.transform.scale(texture, (64, 64))
        self.facing = 'down'
        self.dead = False

    def draw(self, win):
        if self.facing == 'up':
            win.blit(self.texture, (self.x - self.radius, self.y - self.radius))
        elif self.facing == 'down':
            win.blit(pygame.transform.rotate(self.texture, 180), (self.x - self.radius, self.y - self.radius))
        elif self.facing == 'left':
            win.blit(pygame.transform.rotate(self.texture, 90), (self.x - self.radius, self.y - self.radius))
        else:
            win.blit(pygame.transform.rotate(self.texture, 270), (self.x - self.radius, self.y - self.radius))
        pygame.draw.circle(win, (165, 42, 42), (round(self.x), round(self.y)), self.radius, 1)

    def shoot(self):
        if self.facing == 'up':
            return self.weapons[0].shoot(self.x, self.y - self.radius, (0, -1), 'enemy')
        elif self.facing == 'down':
            return self.weapons[0].shoot(self.x, self.y + self.radius, (0, 1), 'enemy')
        elif self.facing == 'left':
            return self.weapons[0].shoot(self.x - self.radius, self.y, (-1, 0), 'enemy')
        else:
            return self.weapons[0].shoot(self.x + self.radius, self.y, (1, 0), 'enemy')

    def melee_attack(self):
        if self.facing == 'up':
            return self.weapons[1].shoot(self.x, self.y - self.radius, (0, -1), 'enemy')
        elif self.facing == 'down':
            return self.weapons[1].shoot(self.x, self.y + self.radius, (0, 1), 'enemy')
        elif self.facing == 'left':
            return self.weapons[1].shoot(self.x - self.radius, self.y, (-1, 0), 'enemy')
        else:
            return self.weapons[1].shoot(self.x + self.radius, self.y, (1, 0), 'enemy')

    @abstractmethod
    def action(self, player, enemies):
        pass

    def hit(self, value):
        self.hp -= value
        if self.hp <= 0:
            self.__del__()

    def __del__(self):
        self.dead = True

    def loop_tick(self):
        self.weapons[0].reload_loop()
        self.weapons[0].rof_loop()
        self.weapons[1].reload_loop()
        self.weapons[1].rof_loop()

    def rotate_to_player(self, player):
        x_diff = self.x - player.x
        y_diff = self.y - player.y
        if abs(x_diff) > abs(y_diff):
            if x_diff < 0:
                self.facing = 'right'
            else:
                self.facing = 'left'
        else:
            if y_diff < 0:
                self.facing = 'down'
            else:
                self.facing = 'up'


class MeleeEnemy(Enemy):
    def __init__(self, start_pos):
        super().__init__(start_pos[0], start_pos[1], 32, 50, 2, [Knife(), Knife()], textures.melee_enemy)

    def action(self, player, enemies):
        self.rotate_to_player(player)
        self.radius += 10
        if collision_detection(self, player) and self.weapons[1].can_shoot():
            self.radius -= 10
            return self.melee_attack()
        self.radius -= 10
        self.move(self.facing)
        if multi_collision(self, player, enemies):
            self.move_back(self.facing)
        return 0

    def drop_ammo(self):
        return Ammo(self.x, self.y, 'knife', random.Random().randint(1, 10), textures.knife)


class PistolEnemy(Enemy):
    def __init__(self, start_pos):
        super().__init__(start_pos[0], start_pos[1], 32, 70, 1.5, [Pistol(), Knife()], textures.pistol_enemy)

    def action(self, player, enemies):
        self.rotate_to_player(player)
        if ok_shoot(self, player) and self.weapons[0].can_shoot():
            return self.shoot()
        else:
            self.radius += 10
            if not self.weapons[0].can_shoot() and collision_detection(self, player) and self.weapons[1].can_shoot():
                self.radius -= 10
                return self.melee_attack()
            self.radius -= 10
            self.move(self.facing)
        if multi_collision(self, player, enemies):
            self.move_back(self.facing)
        return 0

    def drop_ammo(self):
        return Ammo(self.x, self.y, 'pistol', random.Random().randint(3, 7), textures.pistol_ammo)


class ShotgunEnemy(Enemy):
    def __init__(self, start_pos):
        super().__init__(start_pos[0], start_pos[1], 32, 100, 1.2, [Shotgun(), Knife()], textures.shotgun_enemy)

    def action(self, player, enemies):
        self.rotate_to_player(player)
        if ok_shoot(self, player) and self.weapons[0].can_shoot():
            return self.shoot()
        else:
            self.radius += 10
            if not self.weapons[0].can_shoot() and collision_detection(self, player) and self.weapons[1].can_shoot():
                self.radius -= 10
                return self.melee_attack()
            self.radius -= 10
            self.move(self.facing)
        if multi_collision(self, player, enemies):
            self.move_back(self.facing)
        return 0

    def drop_ammo(self):
        return Ammo(self.x, self.y, 'shotgun', random.Random().randint(3, 7), textures.shotgun_ammo)


class RifleEnemy(Enemy):
    def __init__(self, start_pos):
        super().__init__(start_pos[0], start_pos[1], 32, 80, 1.35, [Rifle(), Knife()], textures.rifle_enemy)

    def action(self, player, enemies):
        self.rotate_to_player(player)
        if ok_shoot(self, player) and self.weapons[0].can_shoot():
            return self.shoot()
        else:
            self.radius += 10
            if not self.weapons[0].can_shoot() and collision_detection(self, player) and self.weapons[1].can_shoot():
                self.radius -= 10
                return self.melee_attack()
            self.radius -= 10
            self.move(self.facing)
        if multi_collision(self, player, enemies):
            self.move_back(self.facing)
        return 0

    def drop_ammo(self):
        return Ammo(self.x, self.y, 'rifle', random.Random().randint(4, 9), textures.rifle_ammo)


class SniperEnemy(Enemy):
    def __init__(self, start_pos):
        super().__init__(start_pos[0], start_pos[1], 32, 60, 1, [Sniper(), Knife()], textures.sniper_enemy)

    def action(self, player, enemies):
        self.rotate_to_player(player)
        if ok_shoot(self, player) and self.weapons[0].can_shoot():
            return self.shoot()
        else:
            self.radius += 10
            if not self.weapons[0].can_shoot() and collision_detection(self, player) and self.weapons[1].can_shoot():
                self.radius -= 10
                return self.melee_attack()
            self.radius -= 10
            self.move(self.facing)
        if multi_collision(self, player, enemies):
            self.move_back(self.facing)
        return 0

    def drop_ammo(self):
        return Ammo(self.x, self.y, 'sniper', random.Random().randint(1, 4), textures.sniper_ammo)