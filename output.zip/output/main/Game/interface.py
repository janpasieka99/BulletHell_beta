from Game.textures import *


class Notification(object):
    def __init__(self, message, fontsize=24, message_duration=180):
        self.message = message
        self.message_duration = message_duration
        self.duration_step = 0
        self.my_font = pygame.font.SysFont('Comic Sans MS', fontsize)

    def draw(self, win, in_order):
        win.blit(self.my_font.render(str(self.message), False, (0, 0, 0)), (1200, 3 + in_order * 27))
        self.duration_step += 1


class MidNotification(Notification):
    def draw(self, win, in_order):
        win.blit(self.my_font.render(str(self.message), False, (0, 0, 0)), (700, 20))
        self.duration_step += 1


class Interface(object):
    def __init__(self):
        self.rifle_image = textures.rifle
        self.pistol_image = textures.pistol
        self.knife_image = textures.knife
        self.shotgun_image = textures.shotgun
        self.sniper_image = textures.sniper
        pygame.font.init()
        self.my_font = pygame.font.SysFont('Comic Sans MS', 24)

    def draw_player_interface(self, player, win, wave):
        if player.active_weapon.name == 'rifle':
            win.blit(self.rifle_image, (32, 32))
        elif player.active_weapon.name == 'pistol':
            win.blit(pygame.transform.scale(self.pistol_image, (128, 128)), (32, 32))
        elif player.active_weapon.name == 'knife':
            win.blit(pygame.transform.scale(self.knife_image, (128, 128)), (32, 32))
        elif player.active_weapon.name == 'shotgun':
            win.blit(self.shotgun_image, (32, 32))
        elif player.active_weapon.name == 'sniper':
            win.blit(self.sniper_image, (32, 32))

        win.blit(self.my_font.render(str(player.active_weapon.ammo_in) + ' / ' + str(player.active_weapon.ammo),
                                     False, (0, 0, 0)), (58, 201))
        win.blit(self.my_font.render(str(player.medikits), False, (0, 0, 0)), (129, 264))
        win.blit(self.my_font.render(str(wave), False, (0, 0, 0)), (91, 379))
        if not player.weapons['rifle'].name == 'null':
            win.blit(pygame.transform.scale(self.rifle_image, (80, 80)), (19, 467))
        if not player.weapons['pistol'].name == 'null':
            win.blit(pygame.transform.scale(self.pistol_image, (80, 80)), (19, 567))
        if not player.weapons['knife'].name == 'null':
            win.blit(pygame.transform.scale(self.knife_image, (80, 80)), (19, 667))
        if not player.weapons['shotgun'].name == 'null':
            win.blit(pygame.transform.scale(self.shotgun_image, (80, 72)), (19, 767))
        if not player.weapons['sniper'].name == 'null':
            win.blit(pygame.transform.scale(self.sniper_image, (80, 80)), (19, 859))

        hp_bar = pygame.Rect(183, 948, -63, -1 * round(player.hp / player.hp_cap * (948 - 460)))
        pygame.draw.rect(win, (255, 0, 0), hp_bar)

        win.blit(pygame.transform.rotate(self.my_font.render(str(player.hp) + ' / ' + str(player.hp_cap),
                                                             False, (0, 0, 0)), 90), (135, 651))
