import pygame
from abc import abstractmethod
from abc import ABC


class Character(ABC):
    def __init__(self, x, y, radius, hp, velocity, weapons):
        self.x = x
        self.y = y
        self.radius = radius
        self.hp = hp
        self.hp_cap = hp
        self.velocity = velocity
        self.weapons = weapons
        self.up = True
        self.down = False
        self.left = False
        self.right = False

    def move(self, direction):
        if direction == 'up':
            self.y -= self.velocity
        elif direction == 'down':
            self.y += self.velocity
        elif direction == 'left':
            self.x -= self.velocity
        elif direction == 'right':
            self.x += self.velocity

    def move_back(self, direction):
        if direction == 'up':
            self.y += self.velocity
        elif direction == 'down':
            self.y -= self.velocity
        elif direction == 'left':
            self.x += self.velocity
        elif direction == 'right':
            self.x -= self.velocity

    def rotate(self, direction):
        if direction == 'up':
            self.up = True
            self.down = False
            self.left = False
            self.right = False
        elif direction == 'down':
            self.up = False
            self.down = True
            self.left = False
            self.right = False
        elif direction == 'left':
            self.up = False
            self.down = False
            self.left = True
            self.right = False
        elif direction == 'right':
            self.up = False
            self.down = False
            self.left = False
            self.right = True
        else:
            raise NameError("This direction does not exist.")

    def hit(self, value):
        self.hp -= value
        self.hp = max(self.hp, 0)

    @abstractmethod
    def draw(self, win):
        pass
