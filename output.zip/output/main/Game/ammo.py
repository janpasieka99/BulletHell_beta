from Game.item import Item


class Ammo(Item):
    def __init__(self, x, y, ammo_type, quantity, texture):
        super().__init__('ammo', x, y, texture)
        self.ammo_type = ammo_type
        self.quantity = quantity
