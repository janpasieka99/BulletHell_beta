import math
from Game.player import Player
from Game.weapon import *
from Game.interface import Interface, Notification, MidNotification
from Game.item import Item
from Game.enemy import MeleeEnemy, PistolEnemy, ShotgunEnemy, RifleEnemy, SniperEnemy
from Game.ammo import Ammo
from Game.textures import *
from Game.wave import SpawnPoint, Wave
import random


def collision_detection(character1, character2):
    distance = math.sqrt(((character1.x - character2.x) ** 2) + ((character1.y - character2.y) ** 2))
    if distance <= character1.radius + character2.radius:
        return True
    else:
        return False


def redrawGameWindow(win, bullets, items, man, interface, wave, enemies, notifs, spawn_points):
    win.blit(textures.bg1, (0, 0))
    interface.draw_player_interface(man, win, wave)
    for spawn_point in spawn_points:
        spawn_point.draw(win)
    for item in items:
        item.draw(win)
    for bullet in bullets:
        bullet.draw(win)
    for enemy in enemies:
        enemy.draw(win)
    man.draw(win)
    itr = 0
    for notif in notifs:
        notif.draw(win, itr)
        itr += 1
        if notif.duration_step == notif.message_duration:
            notifs.pop(notifs.index(notif))

    pygame.display.update()


map_x = 1440
map_y = 960

weapon_null = Weapon('null', 0, 0, 0, -1, 0, 0, -1)

starting_weapons = {'rifle': weapon_null, 'pistol': weapon_null, 'knife': Knife(), 'shotgun': weapon_null, 'sniper': weapon_null}


def main():
    interface = Interface()
    wave = Wave(3, 1)
    wave.generate()
    pygame.init()
    win = pygame.display.set_mode((map_x, map_y))
    pygame.display.set_caption("Bullet Hell")
    clock = pygame.time.Clock()
    man = Player(800, 560, 32, 100, 5, starting_weapons)
    bullets = []
    notifs = []
    paused = False
    items = []
    enemies = []
    spawn_points = [SpawnPoint(1340, 100), SpawnPoint(300, 100), SpawnPoint(1340, 900), SpawnPoint(300, 900)]
    run = True
    while run and not man.lost:
        clock.tick(60)
        man.loop_tick()
        if wave.ended(enemies):
            if wave.just_ended():
                items.append(Item('hp_kit', 900, 700, textures.heal))
                if wave.num == 2:
                    items.append(Item('pistol', man.x, man.y, textures.pistol))
                if wave.num == 5:
                    items.append(Item('shotgun', man.x, man.y, textures.shotgun))
                if wave.num == 10:
                    items.append(Item('rifle', man.x, man.y, textures.rifle))
                if wave.num == 20:
                    items.append(Item('sniper', man.x, man.y, textures.sniper))
                if not wave.num % 5:
                    man.hp_cap += 20
                    man.hp += 20
                for weapon in man.weapons:
                    if isinstance(man.weapons[weapon], Weapon):
                        if not man.weapons[weapon].name == 'null':
                            man.weapons[weapon].damage *= 1.05
            if wave.pause_tick % 60 == 1:
                notifs.append(MidNotification("Next wave in " + str(10 - wave.pause_tick//60), 30, 60))
            if wave.available():
                wave = wave.__next__()
                wave.generate()

        current_spawn_point = random.Random().choice(spawn_points)
        if isinstance(current_spawn_point, SpawnPoint):
            if current_spawn_point.is_empty(enemies, man):
                tmp = current_spawn_point.pull_enemy(enemies, man, wave.wave)
                if not isinstance(tmp, int):
                    temp_enemy, wave.wave = tmp
                    enemies.append(temp_enemy)

        for enemy in enemies:
            enemy.loop_tick()
            output = enemy.action(man, enemies)
            if not output == 0:
                for bullet in output:
                    bullets.append(bullet)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_p:
                    paused = True

        while paused:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    run = False
                    paused = False
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_p:
                        paused = False
            redrawGameWindow(win, bullets, items, man, interface, '||', enemies, (Notification('Pause', 48), ), spawn_points)

        for bullet in bullets:
            bullet_out = False
            if not bullet.move(196, map_x, 0, map_y):
                bullets.pop(bullets.index(bullet))
                bullet_out = True
            if not bullet_out:
                for enemy in enemies:
                    if bullet.collision_detection(enemy) and bullet.source == 'player':
                        enemy.hit(bullet.damage)
                        try:
                            bullets.pop(bullets.index(bullet))
                        finally:
                            pass
                        bullet_out = True
                    if enemy.dead:
                        enemies.pop(enemies.index(enemy))
                        items.append(enemy.drop_ammo())
            if not bullet_out:
                if bullet.collision_detection(man) and bullet.source == 'enemy':
                    man.hit(bullet.damage)
                    bullets.pop(bullets.index(bullet))

        keys = pygame.key.get_pressed()

        if keys[pygame.K_1]:
            man.select_weapon('rifle')

        if keys[pygame.K_2]:
            man.select_weapon('pistol')

        if keys[pygame.K_3]:
            man.select_weapon('knife')

        if keys[pygame.K_4]:
            man.select_weapon('shotgun')

        if keys[pygame.K_5]:
            man.select_weapon('sniper')

        if keys[pygame.K_w] and man.y - man.radius >= man.velocity:
            man.rotate('up')
            man.move('up')

        if keys[pygame.K_s] and man.y + man.radius <= map_y - man.velocity:
            man.rotate('down')
            man.move('down')

        if keys[pygame.K_a] and man.x - man.radius >= 196 + man.velocity:
            man.rotate('left')
            man.move('left')

        if keys[pygame.K_d] and man.x + man.radius <= map_x - man.velocity:
            man.rotate('right')
            man.move('right')

        if keys[pygame.K_UP]:
            man.rotate('up')
            if man.active_weapon.can_shoot():
                for bullet in man.shoot():
                    bullets.append(bullet)
        elif keys[pygame.K_DOWN]:
            man.rotate('down')
            if man.active_weapon.can_shoot():
                for bullet in man.shoot():
                    bullets.append(bullet)
        elif keys[pygame.K_LEFT]:
            man.rotate('left')
            if man.active_weapon.can_shoot():
                for bullet in man.shoot():
                    bullets.append(bullet)
        elif keys[pygame.K_RIGHT]:
            man.rotate('right')
            if man.active_weapon.can_shoot():
                for bullet in man.shoot():
                    bullets.append(bullet)

        if keys[pygame.K_r] and not man.active_weapon.reload_tick:
            man.active_weapon.reload()

        if keys[pygame.K_f] and not man.hp_tick:
            man.use_kit()

        if keys[pygame.K_e]:
            for item in items:
                if collision_detection(item, man):
                    if man.pickup_item(item):
                        items.pop(items.index(item))
                        if isinstance(item, Ammo):
                            notifs.append(Notification(str(item.ammo_type) + ' ammo ' + str(item.quantity)))

        redrawGameWindow(win, bullets, items, man, interface, wave.num, enemies, notifs, spawn_points)


if __name__ == '__main__':
    main()
