from Game.character import *
from Game.item import Item
from Game.ammo import Ammo
from Game.weapon import *
from Game.textures import *


class Player(Character):
    def __init__(self, x, y, radius, hp, velocity, weapons):
        super().__init__(x, y, radius, hp, velocity, weapons)
        self.active_weapon = weapons['knife']
        self.medikits = 1
        self.hp_tick = 0
        self.lost = False
        self.texture = pygame.transform.scale(textures.p1, (64, 64))

    def heal(self, value):
        self.hp = min(self.hp_cap, self.hp + value)

    def hp_loop(self):
        if self.hp_tick > 0:
            self.hp_tick += 1
        if self.hp_tick == 30:
            self.hp_tick = 0

    def loop_tick(self):
        self.hp_loop()
        self.active_weapon.reload_loop()
        self.active_weapon.rof_loop()

    def use_kit(self):
        if self.medikits:
            self.medikits -= 1
            self.hp_tick = 1
            self.heal(50)

    def select_weapon(self, name):
        if not self.weapons[name].name == 'null':
            self.active_weapon = self.weapons[name]

    def facing(self):
        if self.up:
            return 'up'
        elif self.down:
            return 'down'
        elif self.left:
            return 'left'
        else:
            return 'right'

    def hit(self, value):
        super().hit(value)
        if self.hp <= 0:
            self.lost = True

    def pickup_item(self, item):
        if isinstance(item, Ammo) and item.ammo_type == self.active_weapon.name:
            self.active_weapon.pickup_ammo(item)
            return True
        elif isinstance(item, Item) and not item.type == 'ammo':
            if item.type == 'rifle':
                self.weapons[item.type] = Rifle()
            elif item.type == 'pistol':
                self.weapons[item.type] = Pistol()
            elif item.type == 'shotgun':
                self.weapons[item.type] = Shotgun()
            elif item.type == 'sniper':
                self.weapons[item.type] = Sniper()
            elif item.type == 'hp_kit':
                self.medikits += 1
            return True
        return False

    def shoot(self):
        if self.up:
            return self.active_weapon.shoot(self.x, self.y - self.radius, (0, -1), 'player')
        elif self.down:
            return self.active_weapon.shoot(self.x, self.y + self.radius, (0, 1), 'player')
        elif self.left:
            return self.active_weapon.shoot(self.x - self.radius, self.y, (-1, 0), 'player')
        elif self.right:
            return self.active_weapon.shoot(self.x + self.radius, self.y, (1, 0), 'player')

    def draw(self, win):
        if self.up:
            win.blit(self.texture, (self.x - self.radius, self.y - self.radius))
        elif self.down:
            win.blit(pygame.transform.rotate(self.texture, 180), (self.x - self.radius, self.y - self.radius))
        elif self.left:
            win.blit(pygame.transform.rotate(self.texture, 90), (self.x - self.radius, self.y - self.radius))
        elif self.right:
            win.blit(pygame.transform.rotate(self.texture, 270), (self.x - self.radius, self.y - self.radius))
        self.active_weapon.draw_reload_progress_bar(win, self.x, self.y, self.radius)
        pygame.draw.circle(win, (165,42,42), (self.x, self.y), self.radius, 1)
