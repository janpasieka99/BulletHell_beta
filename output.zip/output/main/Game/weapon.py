import pygame
from Game.projectile import Projectile


class Weapon(object):
    def __init__(self, name, ammo, ammo_cap, damage, rof, bullet_range, bullet_velocity, reload_time):
        self.name = name
        self.ammo_in = ammo
        self.ammo_in_cap = ammo
        self.ammo = ammo * 2
        self.ammo_cap = ammo_cap
        self.damage = damage
        self.rof = rof
        self.rof_tick = 0
        self.reload_time = reload_time
        self.reload_tick = 0
        self.bullet_range = bullet_range
        self.bullet_velocity = bullet_velocity

    def shoot(self, x, y, facing, source):
        self.rof_tick = 1
        self.ammo_in -= 1

    def reload(self):
        self.reload_tick = 1

    def can_shoot(self):
        if self.reload_tick == 0 and self.rof_tick == 0 and not self.ammo_in == 0:
            return True
        else:
            return False

    def draw_reload_progress_bar(self, win, x, y, radius):
        if not self.reload_tick == 0:
            outer_bar = pygame.Rect(x - radius + 8, y + radius + 2, 2 * radius - 16,  6)
            inner_bar = pygame.Rect(x - radius + 7, y + radius + 3,
                                   round((2 * radius - 14) * self.reload_tick / self.reload_time), 4)
            pygame.draw.rect(win, (0, 0, 0), outer_bar, 1)
            pygame.draw.rect(win, (0, 0, 0), inner_bar)

    def reload_loop(self):
        if self.reload_tick > 0:
            self.reload_tick += 1
        if self.reload_tick == self.reload_time:
            if self.ammo < self.ammo_in_cap:
                self.ammo_in = self.ammo
                self.ammo = 0
            else:
                self.ammo_in = self.ammo_in_cap
                self.ammo -= self.ammo_in_cap
            self.reload_tick = 0

    def rof_loop(self):
        if self.rof_tick > 0:
            self.rof_tick += 1
        if self.rof_tick == self.rof:
            self.rof_tick = 0

    def pickup_ammo(self, ammo):
        if ammo.ammo_type == self.name:
            if self.ammo == self.ammo_cap:
                pass
            else:
                self.ammo = min(self.ammo + ammo.quantity, self.ammo_cap)
                ammo.__del__()
        else:
            pass


class Rifle(Weapon):
    def __init__(self):
        super().__init__('rifle', 30, 120, 20, 10, 64, 10, 120)

    def shoot(self, x, y, facing, source):
        super().shoot(x, y, facing, source)
        return (Projectile(x, y, 5, facing, self.bullet_range, (255, 207, 158), self.damage, self.bullet_velocity, source), )


class Pistol(Weapon):
    def __init__(self):
        super().__init__('pistol', 15, 60, 15, 20, 48, 7, 60)

    def shoot(self, x, y, facing, source):
        super().shoot(x, y, facing, source)
        return (Projectile(x, y, 3, facing, self.bullet_range, (255, 207, 158), self.damage, self.bullet_velocity, source), )


class Knife(Weapon):
    def __init__(self):
        super().__init__('knife', 10, 999, 50, 30, 3, 3, 10)

    def shoot(self, x, y, facing, source):
        super().shoot(x, y, facing, source)
        return (Projectile(x, y, 40, facing, self.bullet_range, (255, 207, 158), self.damage, self.bullet_velocity, source), )


class Shotgun(Weapon):
    def __init__(self):
        super().__init__('shotgun', 8, 32, 25, 30, 32, 10, 180)

    def shoot(self, x, y, facing, source):
        super().shoot(x, y, facing, source)
        if facing[0] == 0:
            return (Projectile(x, y, 6, facing, self.bullet_range, (255, 207, 158), self.damage, self.bullet_velocity, source),
                    Projectile(x, y, 6, (facing[0] - 0.1, facing[1] * 0.9), self.bullet_range, (255, 207, 158),
                               self.damage, self.bullet_velocity, source),
                    Projectile(x, y, 6, (facing[0] + 0.1, facing[1] * 0.9), self.bullet_range, (255, 207, 158),
                               self.damage, self.bullet_velocity, source))
        else:
            return (Projectile(x, y, 6, facing, self.bullet_range, (255, 207, 158), self.damage, self.bullet_velocity, source),
                    Projectile(x, y, 6, (facing[0] * 0.9, facing[1] - 0.1), self.bullet_range, (255, 207, 158),
                               self.damage, self.bullet_velocity, source),
                    Projectile(x, y, 6, (facing[0] * 0.9, facing[1] + 0.1), self.bullet_range, (255, 207, 158),
                               self.damage, self.bullet_velocity, source))


class Sniper(Weapon):
    def __init__(self):
        super().__init__('sniper', 5, 20, 80, 90, 100, 25, 240)

    def shoot(self, x, y, facing, source):
        super().shoot(x, y, facing, source)
        return (Projectile(x, y, 12, facing, self.bullet_range, (255, 207, 158), self.damage, self.bullet_velocity, source), )
